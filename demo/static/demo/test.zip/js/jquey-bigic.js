function but(index) {  //给submit绑定点击事件
    var b = document.getElementById(index); //获取透明层
    b.style.display = "block";  //点击提交显示透明层
}
function CloseDiv(show_div)
{
document.getElementById(show_div).style.display='none';

};
